<!DOCTYPE html>
<html lang="en" class=" js csstransitions"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="smart umri, smartumri, sistem umri, sisfo umri">
    <meta name="description" content="SMART UMRI">
    <meta name="author" content="heruprambadi@gmail.com">
    <link rel="shortcut icon" href="<?= base_url('application/modules/front/assets/template/favicon.gif') ?>">

    <title>SMART UMRI</title>
        
    
    <link rel="stylesheet" type="text/css" href="<?= base_url('application/modules/front/assets/template/bootstrap.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('application/modules/front/assets/template/component.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url('application/modules/front/assets/template/default.css') ?>">
    
    <style type="text/css">
    body{  
      background: url('http://aeknatio.co.id/wp-content/uploads/2014/08/front1.jpg') ?>);background-repeat: no-repeat;
      background-position: 50% 0%;
      background-size: 60% 120%!important;
      background-attachment:fixed;
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }
    </style>

    <script src="<?= base_url('application/modules/front/assets/template/modernizr.custom.js') ?>"></script>
    <script type="text/javascript" async="" src="<?= base_url('welcome_files/request') ?>"></script>
    </head>
    <body>
    <div class="main">
        <div class="container">
            <div class="main">
                <ul id="og-grid" class="og-grid">
                    <li>
                        <a href="<?= site_url('monev/auth/login/pegawai_monev') ?>" class="alink" data-title="">
                            <img src="<?= base_url('application/modules/front/assets/template/lp2km.png') ?>" alt="LPPM" class="img">
                        </a>
                    </li>
                            
                    <li>
                        <a href="<?= ('auth/login/data_akademik') ?>" class="alink" data-title="">
                            <img src="<?= base_url('application/modules/front/assets/template/akademik.png') ?>" alt="Akademik" class="img">
                        </a>
                    </li>
                            
                    <li>
                        <a href="http://keuangan.umri.ac.id" class="alink" data-title="" >
                            <img src="<?= base_url('application/modules/front/assets/template/keuangan.png') ?>" alt="Keuangan" class="img">
                        </a>
                    </li>
                            <br>
                    <li>
                        <a href="http://adm.umri.ac.id">
                            <img src="<?= base_url('application/modules/front/assets/template/umum.png') ?>" alt="Administrasi Unit Kerja" class="img">
                        </a>
                    </li>
                            
                    <li>
                        <a href="<?= site_url('personalia/data/pegawai') ?>" class="alink" >
                            <img src="<?= base_url('application/modules/front/assets/template/kepegawaian.png') ?>" alt="Kepegawaian" class="img">
                        </a>
                    </li>
                            
                    <li>
                        <a href="<?= site_url('personalia/user/umum') ?>" class="alink" >
                            <img src="<?= base_url('application/modules/front/assets/template/peg4.png') ?>" alt="Pegawai" class="img" class="img">
                        </a>
                    </li>
                            <br>
                    <li>
                        <a href="<?= site_url('auth/login/personalia') ?>">
                            <img src="<?= base_url('application/modules/front/assets/template/rapat.png') ?>" alt="Rapat" class="img">
                        </a>
                    </li>
                            
                    <li>
                        <a href="http://smartlib.umri.ac.id" class="alink" >
                            <img src="<?= base_url('application/modules/front/assets/template/lib.png') ?>" alt="Library" class="img">
                        </a>
                    </li>
                            
                    <li>
                        <a href="http://inventori.umri.ac.id" class="alink" >
                            <img src="<?= base_url('application/modules/front/assets/template/inventory.png') ?>" alt="Inventory" class="img">
                        </a>
                    </li>
                </ul> 
            </div>
        </div>
<!-- /container -->
        
        <script src="<?= base_url('application/modules/front/assets/template/jquery.min.js') ?>"></script>

</div></body></html>